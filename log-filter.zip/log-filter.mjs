#!/usr/bin/env node
import fs from "node:fs";
import readline from "node:readline";

// datum a cas na miru testovacimu logu
const NOW = "2025-03-06T00:00:00.015Z";
const STATS_DATE = "2025-03-05";
const FILTER_MINUTES = 15;
const HOUR_MS = 60 * 60 * 1000;

const args = Object.fromEntries(
  process.argv
    .slice(2)
    .reduce((acc, x, i, arr) => {
      if (x.startsWith("--")) acc.push([x.slice(2), arr[i + 1] ?? true]);
      return acc;
    }, [])
);

function usage(code = 1) {
  console.error(
    "Usage: node logtool.mjs --file <file.log> [--hour 0-23] " +
    "[--user <id>] [--service <name>] [--out <file>]"
  );
  process.exit(code);
}

function percentile(arr, p) {
  const sorted = [...arr].sort((x, y) => x - y);
  const index = (p) * (sorted.length - 1);
  return sorted[Math.round(index)];
}

// vypocet hodinovych statistik
async function stats(file, hour) {
  const hh = String(hour).padStart(2, "0");
  const startMs = new Date(STATS_DATE + "T" + hh + ":00:00.000Z").getTime();
  const endMs = startMs + HOUR_MS;

  let total = 0;
  const ok = [];

  const rl = readline.createInterface({
    input: fs.createReadStream(file, "utf8")
  });

  for await (const line of rl) {
    const log = JSON.parse(line);
    if (!log.timestamp) continue;
    const time = new Date(log.timestamp).getTime();

    if (time < startMs || time >= endMs) continue;

    total++;

    if (log.status_code >= 200 && log.status_code < 300) {
      ok.push(log.response_time_ms);
    }
  }

  const avg = total / 60;
  console.log("Pocet za minutu", avg);
  console.log("p50", percentile(ok, 0.5));
  console.log("p95", percentile(ok, 0.95));
}

// filtrovani podle uzivatele a sluzby
async function filter(file, { user, service, outFile }) {

  const nowMs = new Date(NOW).getTime();
  const startMs = nowMs - FILTER_MINUTES * 60000;

  const out = fs.createWriteStream(outFile, "utf8");

  const rl = readline.createInterface({
    input: fs.createReadStream(file, "utf8")
  });

  for await (const line of rl) {
    const log = JSON.parse(line);

    if (!log.timestamp) continue;

    const time = new Date(log.timestamp).getTime();

    if (time <= startMs || time > nowMs) continue;

    if (user && log.user_id !== user) continue;
    if (service && log.service_name !== service) continue;

    out.write(line + "\n");
  }

  await new Promise((r, j) => {
    out.end(r);
    out.on("error", j);
  });
}

if (!args.file) usage(0);

const hour = args.hour != null ? Number(args.hour) : null;
if (hour != null && (!Number.isInteger(hour) || hour < 0 || hour > 23)) {
  throw new Error("--hour must be 0-23");
}

const user = args.user != null ? String(args.user) : null;
const service = args.service != null ? String(args.service) : null;
const outFile = args.out != null ? String(args.out) : "output.log";

if (hour == null && !user && !service) usage(0);

if (hour != null) await stats(args.file, hour);
if (user || service) await filter(args.file, { user, service, outFile });